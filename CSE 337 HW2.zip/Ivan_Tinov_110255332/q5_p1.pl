# CSE 337 HW2, Ivan Tinov, ID# 110255332

first regex:  (be)+[\s\w]*(to be)



second regex:  [\w]*[!.?]

