import tkinter as Tkinter

root = Tkinter.Tk()
root.title("Hello example")
root.geometry("200x100")

w1 = Tkinter.Label(root, text="First text")
w2 = Tkinter.Label(root, text="Second text")
w3 = Tkinter.Label(root, text="Third text")
w1.pack() #padx and pady and SIDE are optional
w2.pack()
w3.pack()

root.mainloop()

