# CSE 337 HW2, Ivan Tinov, ID# 110255332

use strict;
use warnings;

my @numList = (0,0,0,0,0,0,0,0,0,0);
my $f = "features.txt";
open(IN, '<', $f);
while(<IN>){
	my @cut = split /[\s+,]/, $_;
	my $feature = $cut[-1] + 0;
	my $listSize = @cut;
	$numList[$feature] = $listSize - 1;
}

for (my $x = 0; $x < 10; $x++) {
	
	print "total_#_of_words_with_" . "$x:$numList[$x]" . "\n";
}