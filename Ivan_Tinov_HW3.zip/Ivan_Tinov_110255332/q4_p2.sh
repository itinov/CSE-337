#!/bin/bash

for i in 1 2 3 4 5 6 7 8 9 10
do
	mydir=""
	rem=$(($i %2))
	
	if !(($rem))
	then
		mydir="even" 
		mydir="$mydir$i"
		mkdir "$mydir"
		chmod a+r "$mydir"
		chmod u+w "$mydir"
		chmod g+w "$mydir"
		chmod a-x "$mydir"
	else
		mydir="odd"
		mydir="$mydir$i"
		mkdir "$mydir"
		chmod a+r "$mydir"
		chmod a-w "$mydir"
		chmod a-x "$mydir"
	fi
done