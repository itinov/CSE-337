# CSE 337 HW2, Ivan Tinov, ID# 110255332

use strict;
use warnings;
use Data::Dumper;

my %income;

$income{"1"} = 4840;
$income{"2"} = 4340;
$income{"3"} = 3900;
$income{"4"} = 4330;
$income{"5"} = 3090;
$income{"6"} = 3660;
$income{"7"} = 3520;
$income{"8"} = 3280;
$income{"9"} = 4130;
$income{"10"} = 3690;
$income{"11"} = 4260;
$income{"12"} = 4800;

my @monthName = ("jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec");
my @monthNum = qw(1 2 3 4 5 6 7 8 9 10 11 12);

my %month;
@month{@monthName} = @monthNum;


my $firstVal = 1;
my $firstMonth = "";
while ($firstVal){
	
	print "Enter the First Month: ";
	$firstMonth = <STDIN>;
	chomp($firstMonth);
	my $firstMonth = lc($firstMonth);
	foreach my $key (keys %month) {
		if ($firstMonth eq $key) {
			$firstVal = 0;
		}
	}
	if ($firstVal == 1) {
		print "Please enter only the three initials letters of a valid month.\n";
	}
}

my $lastVal = 1;
my $lastMonth = "";
while ($lastVal){
	
	print "Enter the Last Month: ";
	$lastMonth = <STDIN>;
	chomp($lastMonth);
	my $lastMonth = lc($lastMonth);
	foreach my $key (keys %month) {
		if ($lastMonth eq $key) {
			$lastVal = 0;
		}
	}
	if ($lastVal == 1) {
		print "Please enter only the three initials letters of a valid month.\n";
	}
}

my $r = 0;

print "The Total Income is: ";
my $first = $month{$firstMonth};
my $last = $month{$lastMonth};
if ($first == $last) {
	print "$r";
}

if ($first < $last) {
	for (my $count = $first; $count <= $last; $count++) {
		$r += $income{"$count"};
	}
	print "$r";
} 
else {
	my $next = $first + 1;
	print($income{"$first"} + $income{"$next"});
}
