#!/bin/bash

cd $1
username=$whoami
echo "Current shell is $SHELL"
echo "Current directory is $PWD"
echo "Home directory is $HOME"
echo ""
echo "--5 most recently non-empty subdirectories--"
find . -type d -perm -777 | head -5

echo ""
echo "--Files in last 45 minutes"
find . -maxdepth 1 -type f -mmin +45
echo ""
echo "======================================================================"