# CSE 337 HW2, Ivan Tinov, ID# 110255332

First Regex: [-+]?\d*(\.\D+)?F\s
Match:
208F
+2048F
408F

No Match:
37s2D
+ss382G
9a823D

Second Regex:(#?)(1?)(one)\1\2\3
Match:

No Match:
hello
bye
no


Third Regex: ((a*?)\b).*\w\2\1
Match:
hello
who
is

No Match:
@@@@
!!!..
***@%^#

