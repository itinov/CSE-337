import tkinter as Tkinter 

root = Tkinter.Tk()
root.title("Hello example")
root.geometry("350x250")

w1 = Tkinter.Label(root, text="First text", font=("Times", 36))
w2 = Tkinter.Label(root, text="Second text", font=("Times", 36))
w3 = Tkinter.Label(root, text="Third text", font=("Times", 36))
w1.place(x=0,y=0) # also height and width
w2.place(x=80,y=80)
w3.place(x=160,y=160)

root.mainloop()
