open OUTP, ">some_random_file.txt";
$line = "This is the file content";
print OUTP $line;
close OUTP;
