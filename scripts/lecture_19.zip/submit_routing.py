from flask import Flask, render_template, redirect
from text_form import SubmissionForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'somesecretkey'


@app.route('/', methods=['GET', 'POST'])
def login():
    form = SubmissionForm()
    if form.validate_on_submit():
        name = form.name.data
        story = form.text.data
        return "Welcome, " + name + "<br>Here is your story:<br>" + story
    return render_template('submit.html', title='Submit', form=form)


if __name__ == '__main__':
    app.run()
