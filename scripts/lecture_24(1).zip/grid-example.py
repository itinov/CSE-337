import tkinter as Tkinter

root = Tkinter.Tk()
root.title("Hello example")
root.geometry("200x100")

w1 = Tkinter.Label(root, text="First text")
w2 = Tkinter.Label(root, text="Second text")
w3 = Tkinter.Label(root, text="Third text")
w1.grid(column=0)
w2.grid(column=1)
w3.grid(column=2)

root.mainloop()

