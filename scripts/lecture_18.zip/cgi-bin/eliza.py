#!/usr/bin/python

import cgi

import string



def getReply (line,words):

    #find a reply based on the words

    if len(words)==0: return "You have to talk to me."

    if line[-1]=='?': return "Why do you want to know?"

    if "mother" in words: return "Tell me more about your mother."

    if "father" in words: return "Tell me more about your father."

    if "uncle" in words: return "Tell me more about your uncle."

    if "sister" in words: return "Tell me more about your sister."

    if "brother" in words: return "Tell me more about your brother."

    if words[0]=="I" and words[1]=="feel": return "Why do you feel that way?"

    if words[0]=="I" and words[1]=="think": return "Do you really think so?"

    return "Tell me more. "



print "Content-type: text/html"

print

print "<html><body>"

print "<title>Eliza Program</title>"

print "<h1>Couch</h1>"



form = cgi.FieldStorage()



if not form:

	reply = "You have to talk to me"

else:

 	#figure out our reply

	line = form['line'].value

	print '<p><i>' + line + '</i>'

	reply = getReply(line, string.split(line))



print '<p><form action = "/cgi-bin/eliza.py" method="POST">'

print '<p>' + reply

print '<p><input type="text" name="line" size="80">'

print '<br><input type="submit" value="submit new entry">'

print '</form></body>'

print '</html>'
