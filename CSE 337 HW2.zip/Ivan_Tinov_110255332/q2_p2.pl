# CSE 337 HW2, Ivan Tinov, ID# 110255332

use strict;
use warnings;

print "Sample Input:\n";

my $s1 = <STDIN>;
chomp $s1;

my $inF = "q2.in";
my $outF = "q2_p2.out";
open(IN, '<', $inF);
open(OUT, '>', $outF);

print "sample q2_p2.out:\n";
my $count = 0;

while(<IN>){
	my @cut = split ' ', $_;
	my $listSize = @cut;

	if ($listSize  != $s1) {
		print $_;  
		print OUT $_ ; 
	} else {
		$count += 1;
	}
}

if ($count == 0) {
	print "Oooh Nooo!";
}