from flask_wtf import FlaskForm
from wtforms import StringField, TextField, SubmitField, TextAreaField
from wtforms.validators import DataRequired

class SubmissionForm(FlaskForm):
    name = StringField('Name') # validators=[DataRequired()])
    text = TextAreaField('Your Story') # validators=[DataRequired()])
    submit = SubmitField('Submit')
