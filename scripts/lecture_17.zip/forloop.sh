#!/bin/bash
a=0
b=1
for i in `seq 1 5`;
do
	a=$((a+b))
	echo $a
	b=$((a+b))
	echo $b
done
