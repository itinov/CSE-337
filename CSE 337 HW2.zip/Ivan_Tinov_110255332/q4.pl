# CSE 337 HW2, Ivan Tinov, ID# 110255332

use strict;
use warnings;

my $directory = "features";
unless(mkdir $directory) {
	die "Unable to create $directory\n";
}

for (my $i=0; $i <= 9; $i++) {
	my $file = "$directory/$i-features.txt";
	my $filehandle;
	unless(open $filehandle, ">", $file){
  		die "\nUnable to create $file:\n$!";
	}
	printf $filehandle "testing writng\n";
	printf $filehandle "testing2\n";
	close($filehandle);
}



