from flask import Flask, render_template

app = Flask(__name__)


@app.route('/<studentname>')
def index(studentname):
    ali_info = {'name': 'Ali', 'address':'Stony Brook Univerity', 'zipcode': '11790'}
    ying_info = {'name': 'Ying', 'address':'White House', 'zipcode': '12345'}
    david_info = {'name': 'David', 'address':'Bloomberg Tower', 'zipcode': '54321'}
    student_info_dict = {'ali': ali_info, 'ying': ying_info, 'david': david_info}
    return render_template('student_info.html', title='Student Information Page', student=student_info_dict[studentname])


if __name__ == '__main__':
    app.run()
