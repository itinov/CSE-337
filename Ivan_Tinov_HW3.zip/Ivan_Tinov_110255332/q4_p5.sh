#!/bin/bash
count=$#
total=0
min=100000000
max=0

for i do
	echo $i
	if (($i<min))
	then
		min=$i
	elif (($i>max))
	then
		max=$i
	((total+=$i))
	fi
done
mean=$((total/count))
echo "Min: $min, Max: $max, and Mean: $mean"