from tkinter import *

root = Tk()
root.title("Hello example")
root.geometry("200x150")

w1 = Label(root, text="First text", fg="blue", bg="red")
w2 = Label(root, text="Second text",underline=0)
w3 = Label(root, text="Third text")
w1.place(x=50,y=50)
w2.place(x=50,y=80)
w3.place(x=50,y=110)

root.mainloop()
