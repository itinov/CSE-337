sub twoargs {
$name = $_[0];
$surname = $_[1];

print $name;
print $surname;
  
}


twoargs("hello", "world");
