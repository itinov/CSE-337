# CSE 337 HW2, Ivan Tinov, ID# 110255332

require "./q1_helper.pl";

use strict;
use warnings;

my $young = -1;
my $youngID = -1;
my $old = 10000;
my $oldID = -1;

my $f = 'collections.csv';
my %collections = read_csv($f);

while(my($x,$y) = each %collections) {
	if (@$y[2] < $old){
		$oldID = $x;
		$old = @$y[2];	}
	if (@$y[2] > $young){
		$youngID = $x;
		$young = @$y[2];
	}
}

print "Sample Output:\n";
print $oldID . "\n";
print $youngID . "\n";