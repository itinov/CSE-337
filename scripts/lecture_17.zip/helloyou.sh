#!/bin/bash
echo -n "Please enter your name: "
read user_name

if [ -n "$user_name" ];
then echo "Hello, $user_name!"
exit 0

else
echo "Please tell me your name next time"
exit 1
fi
