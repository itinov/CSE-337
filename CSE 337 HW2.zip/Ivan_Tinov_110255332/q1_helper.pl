# CSE 337 HW2, Ivan Tinov, ID# 110255332
# q1_p1.pl helper


use strict;

use warnings;



sub read_csv {
	
	my $file = $_[0];
	
	open(my $f, '<', $file);
	
	my %hash;
	
	my $fLine = <$f>;
	
	while(my $line = <$f>){
		
		chomp $line;
		
		(my $id, my $name, my $country, my $year) = split /,/, $line;
		
		$hash{$id} = [$name, $country, $year + 0];
	
	}
	
	close $f;
	
	return %hash;

}
1;
 
