import shelve
from tkinter import *
from tkinter import messagebox

data = shelve.open("database")
root = Tk()
root.geometry("1000x400")
root.title("Calculator application")

# make some of the widgets
cmd = IntVar()
lab = Label(root, text="Command:", font=('Helvetica', 24))
k1  = Label(root, text="key/search", font=('Helvetica', 24))
ke  = Entry(root, width=40, font=('Helvetica', 24))
vl  = Label(root, text="value", font=('Helvetica', 24))
ve  = Text(root, width=40, height=5, font=('Helvetica', 24))

def searchfun(evt=None):
    cmd.set(1)
    doRadio()

def insertfun(evt=None):
    cmd.set(2)
    doRadio()

def removefun(evt=None):
    cmd.set(3)
    doRadio()

def doRadio():
    c = cmd.get() # get the command number
    if c == 1: # search with a given name
        ve.delete("1.0", END)
        if ke.get() in data:
            ve.insert(END, data[ke.get()])
        elif ke.get() != "":
            #ve.insert(END,"no information for key " + ke.get())
            messagebox.showerror("Error", "No information for key " + ke.get())
    elif c == 2: # insert a (name, phone number) record
        data[ke.get()] = ve.get("1.0", END)
        #ve.delete("1.0", END)
        #ve.insert(END, "database has been updated")
        messagebox.showinfo("Success", "Database has been updated!")
    else: # delete the record with given name
        del data[ke.get()]
        #ve.delete("1.0", END)
        #ve.insert(END, "entry has been deleted")
        messagebox.showinfo("Success", "Entry has been deleted!")

menubar = Menu(root)
fontMenu = Menu(menubar)
fontMenu.add("command",label="Search",command=searchfun, font=('Helvetica', 24))
fontMenu.add("command",label="Insert", command=insertfun, font=('Helvetica', 24))
fontMenu.add("command",label="Remove", command=removefun, font=('Helvetica', 24))
menubar.add("cascade",label="Font", menu=fontMenu, font=('Helvetica', 24))

root.bind("<F1>", searchfun)
root.bind("<F2>", insertfun)
root.bind("<F3>", removefun)

# lay out the grid
lab.grid(row=0, column=0)
k1.grid(row=1, column=0) 
ke.grid(row=1, column=1,columnspan=3)
vl.grid(row=2, column=0)
ve.grid(row=2, column=1, columnspan=3)

root.config(menu=menubar)
# loop over main program, save database after user quits
root.focus_set()
root.mainloop()
data.close()