# CSE 337 HW2, Ivan Tinov, ID# 110255332

require "./q1_helper.pl";

use strict;
use warnings;

print "Sample Input:\n";

my $country = <STDIN>;
chomp $country;
my $input = 'collections.csv';
my %csvFile = read_csv($input);
my $count = 0;

foreach my $i (values %csvFile ) {
	if (@$i[1] eq $country) { $count += 1; };}

print "Sample Output:\n";print $count . "\n";