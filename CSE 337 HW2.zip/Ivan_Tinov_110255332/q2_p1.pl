# CSE 337 HW2, Ivan Tinov, ID# 110255332

use strict;

use warnings;



print "Sample Input:\n";


my $s1 = <STDIN>;

chomp $s1;


my $s2 = <STDIN>;

chomp $s2;

print "\n";



my $inF = "q2.in";

my $outF = "q2_p1.out";


open(IN, '<', $inF);

open(OUT, '>', $outF);



while(<IN>){
	
	$_ =~ s/$s1/$s2/g;
	
	print OUT $_;

}



print "Sample 'q2_p1.out':\n";
