from Tkinter import * 

root = Tk()
root.title("Hello example")
root.geometry("200x100")

w = Label(root, text="Hello, world!")
w.pack()

root.mainloop()
