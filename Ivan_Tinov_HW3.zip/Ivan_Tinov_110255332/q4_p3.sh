#!/bin/bash

echo -n "Please, enter a sentence: "
read -e -a sentence
nChars=0
for c in ${sentence[k]}
do
	((nChars+=${#c}))
	((nChars++))
done
((nChars--))
nWords=${#sentence[k]}
echo "$nChars total number of k, and $nWords total words with k"