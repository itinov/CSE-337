from flask import Flask, request
app = Flask(__name__)

@app.route("/",methods=['GET', 'POST'])
def homepage():
	if request.method == 'GET':
		return hello()
	else:
		data = request.form['line']
		return getReply (data,data.split(" ")) + hello()


def hello():
    return '<html> \
<title>Eliza Program</title> \
<body> \
<h1>Phreds Phrendly Pseudo-Psychiatric Couch</h1> \
<p> \
<form action = "/" method="POST"> \
<p> \
Hello. what can we do for you today? \
<p> \
<input type="text" name="line" size="80"> \
<br> \
<input type="submit" value="submit new entry"> \
</form> \
</body> \
</html>'


def getReply (line,words):

    #find a reply based on the words

    if len(words)==0: return "You have to talk to me."

    if line[-1]=='?': return "Why do you want to know?"

    if "mother" in words: return "Tell me more about your mother."

    if "father" in words: return "Tell me more about your father."

    if "uncle" in words: return "Tell me more about your uncle."

    if "sister" in words: return "Tell me more about your sister."

    if "brother" in words: return "Tell me more about your brother."

    if words[0]=="I" and words[1]=="feel": return "Why do you feel that way?"

    if words[0]=="I" and words[1]=="think": return "Do you really think so?"

    return "Tell me more. "


if __name__ == "__main__":
    app.run()


