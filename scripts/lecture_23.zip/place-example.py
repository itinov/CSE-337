import tkinter as Tkinter 

root = Tkinter.Tk()
root.title("Hello example")
root.geometry("200x150")

w1 = Tkinter.Label(root, text="First text")
w2 = Tkinter.Label(root, text="Second text")
w3 = Tkinter.Label(root, text="Third text")
w1.place(x=50,y=50) # also height and width
w2.place(x=50,y=80)
w3.place(x=50,y=110)

root.mainloop()
