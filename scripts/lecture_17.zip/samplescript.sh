echo # skip a line
echo  "Date and Time:"
date # displays current date and time 
echo  "Number of users on the system:"
who | wc -l # displays # users logged in 
echo "Your current directory:"
pwd
echo
